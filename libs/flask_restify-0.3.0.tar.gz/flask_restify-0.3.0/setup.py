from setuptools import setup, find_packages

setup(
    name='flask_restify',
    version='0.3.0',
    packages=find_packages(),
    url='',
    license='',
    author='betas',
    author_email='thou1999@gmail.com',
    description='',
    install_requires=[
        'flask',
        'Flask-SQLAlchemy'
    ],
    include_package_data=True
)
