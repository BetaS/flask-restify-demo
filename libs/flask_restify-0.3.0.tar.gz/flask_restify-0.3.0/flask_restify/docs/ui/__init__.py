# -*- coding: utf-8 -*-

from .ui import get_swaggerui_blueprint
